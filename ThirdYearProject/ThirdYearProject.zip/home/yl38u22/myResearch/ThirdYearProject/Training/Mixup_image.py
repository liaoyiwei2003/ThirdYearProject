import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import optim
from torchbearer import Trial
import torchbearer
from torchvision.datasets import VisionDataset
import matplotlib.pyplot as plt
import torch.nn.functional as F
import random
import numpy as np
import sys
import os

from copy import deepcopy
from torch.optim.lr_scheduler import MultiStepLR
from scipy.stats import beta
from torch.utils.data import DataLoader

def train_model_with_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False

    batch_size = 32
    trainset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=True, download=True,
                                                transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                (0.2023, 0.1994, 0.2010)),]))
    testset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=False, download=True,
                                               transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                                               (0.2023, 0.1994, 0.2010)),]))

    device = 'cuda:2'

    trainloader = DataLoader(trainset_c10, batch_size=128, shuffle=True)
    testloader = DataLoader(testset_c10, batch_size=128, shuffle=True)

    ALPHA = 0.2

    model = torchvision.models.vgg16()
    model.classifier[6] = nn.Linear(in_features=4096, out_features=10, bias=True)
    model = model.to(device)

    loss_function = nn.CrossEntropyLoss()
    optimiser = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimiser, milestones=[100, 150])

    for epoch in range(200):
        running_loss = 0.0
        for data in trainloader:
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)
            
            index = np.random.permutation(inputs.shape[0])
            lam = beta.rvs(ALPHA, ALPHA)
            x1 = inputs
            x2 = inputs[index]
            mixed_inputs = x1 * lam + x2 * (1 - lam)
            
            optimiser.zero_grad()

            outputs = model(mixed_inputs)
            if lam > 0.5:
                loss = loss_function(outputs, labels)
            else:
                loss = loss_function(outputs, labels[index])
                
            loss.backward()
            optimiser.step()
            scheduler.step()

            running_loss += loss.item()
        print("Epoch %d, loss %4.2f" % (epoch, running_loss))
    print('**** Finished Training ****')

    model.eval()

    correct = 0
    total = 0

    for data in testloader:
        inputs, labels = data
        inputs = inputs.to(device)
        labels = labels.to(device)

        outputs = model(inputs)
        _, predicted = torch.max(outputs, 1)
        correct += (predicted == labels).sum().item()
        total += labels.size(0)

    print(total)
    print('Test Accuracy: %2.2f %%' % ((100.0 * correct) / total))

    save_path = f"/ssd/saved_tutorial_models/yl38u22/VGG16_mixup_200_mix_image_seed{seed}.pt"
    torch.save(model.state_dict(), save_path)
    print(f'Model saved to {save_path}')

if __name__ == "__main__":
    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed)
