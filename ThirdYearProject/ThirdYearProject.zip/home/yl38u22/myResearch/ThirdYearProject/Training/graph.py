import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import numpy as np

device = 'cuda:0'

# Fix random seed for reproducibility
seed = 7
torch.manual_seed(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

# Load CIFAR-10 dataset
testset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=False, download=True,
                                           transform=transforms.Compose([
                                               transforms.ToTensor(),
                                               transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                                    (0.2023, 0.1994, 0.2010)),
                                           ]))

testset_mnist = torchvision.datasets.MNIST(root='~/data/mnist', train=False, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,)),]))
from utils import MixedDatasetsDephased
test_domino = MixedDatasetsDephased(testset_mnist, testset_c10, n_cls=10)
test_loader = DataLoader(test_domino, batch_size=128, shuffle=True)

# Function to compute confidences
def get_confidences(model, loader):
    confidences_correct = []
    confidences_incorrect = []
    model.to(device)
    model.eval()
    with torch.no_grad():
        for images, targets in loader:
            images, targets = images.to(device), targets.to(device)
            outputs = model(images)
            probs = nn.functional.softmax(outputs, dim=1)
            confidence, predicted = torch.max(probs, 1)
            
            for i in range(len(images)):
                if predicted[i] == targets[i]:
                    confidences_correct.append(confidence[i].item())
                else:
                    confidences_incorrect.append(confidence[i].item())
                    
    return confidences_correct, confidences_incorrect

# Function to compute accuracy
def compute_accuracy(model, loader):
    correct = 0
    total = 0
    model.to(device)
    model.eval()
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            correct += (predicted == labels).sum().item()
            total += labels.size(0)
    
    accuracy = (100.0 * correct) / total
    return accuracy

# Function to process models and compute confidences
def process_models(model_paths):
    all_confidences_correct = []
    all_confidences_incorrect = []
    all_accuracies = []

    for model_path in model_paths:
        model = torchvision.models.resnet18()
        model.fc = nn.Linear(in_features=512, out_features=10, bias=True)

        model.load_state_dict(torch.load(model_path, map_location=device))
        
        confidences_correct, confidences_incorrect = get_confidences(model, test_loader)
        all_confidences_correct.append(confidences_correct)
        all_confidences_incorrect.append(confidences_incorrect)
        
        accuracy = compute_accuracy(model, test_loader)
        all_accuracies.append(accuracy)
        print(f'Model: {model_path} - Test Accuracy: {accuracy:.2f} %')
    
    return all_confidences_correct, all_confidences_incorrect, all_accuracies

model_paths_miximage = [
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed5.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed6.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed7.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed8.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed9.pt"
]

model_paths_mixlabel = [
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed_normal5.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed_normal6.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed_normal7.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed_normal8.pt",
    "/ssd/saved_tutorial_models/yl38u22/VGG18_dominos_seed_normal9.pt"
]

# Process both sets of models
confidences_correct_miximage, confidences_incorrect_miximage, accuracies_miximage = process_models(model_paths_miximage)
confidences_correct_mixlabel, confidences_incorrect_mixlabel, accuracies_mixlabel = process_models(model_paths_mixlabel)

# Function to calculate the proportion of incorrect predictions above a certain threshold
def calculate_proportion(threshold_correct, threshold_incorrect, confidences_correct, confidences_incorrect):
    confidence_threshold = [confidence for confidence in confidences_correct if confidence > threshold_correct]
    confidence_incorrect_threshold = [confidence for confidence in confidences_incorrect if confidence > threshold_incorrect]
    
    total_selected = len(confidence_threshold) + len(confidence_incorrect_threshold)
    if total_selected == 0:
        return 0
    return (len(confidence_incorrect_threshold) / total_selected) * 100

# Generate data for plotting
thresholds = np.linspace(0, 1, 100)

def compute_proportions(all_confidences_correct, all_confidences_incorrect):
    all_proportions = []
    for confidences_correct, confidences_incorrect in zip(all_confidences_correct, all_confidences_incorrect):
        proportions = [calculate_proportion(0.61, t, confidences_correct, confidences_incorrect) for t in thresholds]
        all_proportions.append(proportions)
    return np.mean(all_proportions, axis=0), np.std(all_proportions, axis=0)

average_proportions_miximage, deviation_proportions_std_miximage = compute_proportions(confidences_correct_miximage, confidences_incorrect_miximage)
average_proportions_mixlabel, deviation_proportions_std_mixlabel = compute_proportions(confidences_correct_mixlabel, confidences_incorrect_mixlabel)

# Plot the results with error bars for both mixup and unmixup
plt.figure(figsize=(20, 6))

plt.errorbar(thresholds, average_proportions_miximage, yerr=deviation_proportions_std_miximage, label='MixDominos: Average Proportion of Incorrect Predictions', fmt='-o', color='blue', ecolor='red', capsize=3)
plt.errorbar(thresholds, average_proportions_mixlabel, yerr=deviation_proportions_std_mixlabel, label='NormalDominos: Average Proportion of Incorrect Predictions', fmt='-o', color='green', ecolor='black', capsize=3)

plt.xlabel('Threshold')
plt.ylabel('Proportion of Incorrect Predictions (%)')
plt.title('Threshold vs. Proportion of Incorrect Predictions for MixImage and Mixlabel Models')
plt.legend()
plt.ylim(0, max(max(average_proportions_miximage + deviation_proportions_std_miximage), max(average_proportions_mixlabel + deviation_proportions_std_mixlabel)) * 1.1)
plt.grid(True)
plt.show()
