
## Plot ad hoc mnist instances
from torchvision.datasets import MNIST
import matplotlib.pyplot as plt
import torchvision
import torch
from torch import nn
from torch import optim
import numpy as np
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
seed = 7
np.random.seed(seed)
np.random.randint(100)


batch_size = 32
trainset_c10 = torchvision.datasets.CIFAR10(root='/data/cifar10', train=True, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),]))
testset_c10 = torchvision.datasets.CIFAR10(root='/data/cifar10', train=False, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),]))

trainset_mnist = torchvision.datasets.MNIST(root='~/data/mnist', train=True, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]))
testset_mnist = torchvision.datasets.MNIST(root='~/data/mnist', train=False, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]))





from utils import MixedDatasetsDephased
train_domino = MixedDatasetsDephased(trainset_mnist, trainset_c10, n_cls=10)
trainloader = DataLoader(train_domino, batch_size=128, shuffle=True)
model = torchvision.models.resnet18()

model.fc = nn.Linear(in_features=512, out_features=10, bias=True)

device = 'cuda:0'
model = model.to(device)


# define the loss function and the optimiser
loss_function = nn.CrossEntropyLoss()
optimiser = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)



# the epoch loop
for epoch in range(200):
    running_loss = 0.0
    for data in trainloader:
        # get the inputs
        inputs, labels = data
        inputs = inputs.to(device)
        labels = labels.to(device)

        # zero the parameter gradients
        optimiser.zero_grad()

        # forward + loss + backward + optimise (update weights)
        outputs = model(inputs)
        loss = loss_function(outputs, labels)
        loss.backward()
        optimiser.step()

        # keep track of the loss this epoch
        running_loss += loss.item()
    print("Epoch %d, loss %4.2f" % (epoch, running_loss))
print('**** Finished Training ****')

torch.save(model.state_dict(), "/ssd/saved_tutorial_models/res18-domino-200.pt")









