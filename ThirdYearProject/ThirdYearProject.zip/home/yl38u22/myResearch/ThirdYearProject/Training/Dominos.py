import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torchbearer import Trial
import torchbearer
from torchvision.datasets import VisionDataset
import matplotlib.pyplot as plt
import torch.nn.functional as F
import random
import numpy as np
import sys
import os

from copy import deepcopy
from torch.optim.lr_scheduler import MultiStepLR
from scipy.stats import beta
from torch.utils.data import DataLoader

import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import optim
from torch.utils.tensorboard import SummaryWriter
import numpy as np
import os
from torch.optim.lr_scheduler import MultiStepLR
from scipy.stats import beta
from torch.utils.data import DataLoader

def create_log_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def train_model_with_seed(seed, lr):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False

    # Define the log directory and file names
    log_dir = os.path.expanduser(f'~/myResearch/log_files/mixup_dominos_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)

    # Define the datasets and data loaders
    trainset_mnist = torchvision.datasets.MNIST(root='~/data/mnist', train=True, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,)),]))
    testset_mnist = torchvision.datasets.MNIST(root='~/data/mnist', train=False, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,)),]))
    trainset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=True, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),]))
    testset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=False, download=True,
                                               transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                                               (0.2023, 0.1994, 0.2010)),]))

    from utils import MixedDatasetsDephased
    train_domino = MixedDatasetsDephased(trainset_mnist, trainset_c10, n_cls=10)
    trainloader = DataLoader(train_domino, batch_size=128, shuffle=True)
    testloader = DataLoader(testset_c10, batch_size=128, shuffle=True)
    model = torchvision.models.resnet18()
    model.fc = nn.Linear(in_features=512, out_features=10, bias=True)

    device = 'cuda:1'
    model = model.to(device)

    ALPHA = 0.2

    loss_function = nn.CrossEntropyLoss()
    optimiser = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimiser, milestones=[100, 150])

    # Initialize TensorBoard writer
    writer = SummaryWriter(log_dir=log_dir)

    # The epoch loop
    for epoch in range(0):
        running_loss = 0.0
        for i, data in enumerate(trainloader, 0):
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)
            
            # Apply MixUp
            index = np.random.permutation(inputs.shape[0])
            lam = beta.rvs(ALPHA, ALPHA)
            x1 = inputs
            x2 = inputs[index]
            _, _, h, w = inputs.shape
            
            mixed_inputs = torch.empty_like(inputs)
            mixed_inputs[:, :, :, :w//2] = x1[:, :, :, :w//2] * lam + x2[:, :, :, :w//2] * (1 - lam)
            
            if lam > 0.5:
                mixed_inputs[:, :, :, w//2:] = x1[:, :, :, w//2:]
            else:
                mixed_inputs[:, :, :, w//2:] = x2[:, :, :, w//2:]
            
            optimiser.zero_grad()

            outputs = model(mixed_inputs)
            if lam > 0.5:
                loss = loss_function(outputs, labels)
            else:
                loss = loss_function(outputs, labels[index])
                
            loss.backward()
            optimiser.step()
            scheduler.step()

            running_loss += loss.item()

        # Log the average loss at the end of each epoch
        avg_loss = running_loss / len(trainloader)
        writer.add_scalar('training_loss', avg_loss, epoch)

        # Log training accuracy
        model.eval()
        correct = 0
        total = 0
        for inputs, labels in DataLoader(train_domino, batch_size=128):
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            correct += (predicted == labels).sum().item()
            total += labels.size(0)
        train_accuracy = 100.0 * correct / total
        writer.add_scalar('training_accuracy', train_accuracy, epoch)
        
        print(f"Epoch {epoch}, Loss: {avg_loss:.2f}, Training Accuracy: {train_accuracy:.2f}%")

    # Evaluate on test set
    model.eval()
    correct = 0
    total = 0
    for inputs, labels in testloader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        _, predicted = torch.max(outputs, 1)
        correct += (predicted == labels).sum().item()
        total += labels.size(0)
    test_accuracy = 100.0 * correct / total
    writer.add_scalar('test_accuracy', test_accuracy)
    
    print(f"Test Accuracy: {test_accuracy:.2f}%")

    save_path = f"/ssd/saved_tutorial_models/yl38u22/RES-18_dominos_seed_test{seed}_lr_{lr}.pt"
    torch.save(model.state_dict(), save_path)
    print(f'Model saved to {save_path}')

    # Close the TensorBoard writer
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train a model with specified learning rate and seed.')
    parser.add_argument('lr', type=float, help='Learning rate for training.')
    args = parser.parse_args()

    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)
