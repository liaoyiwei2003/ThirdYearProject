import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np
import os
import argparse
from torch.utils.tensorboard import SummaryWriter

def create_log_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)
        
def train_model_with_seed(seed, lr):  # Add 'lr' as a second argument
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False

    # Define the log directory and file names
    log_dir = os.path.expanduser(f'~/myResearch/log_files/VGG16_label_smoothing_normal_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)

    batch_size = 128
    trainset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=True, download=True,
                                                transform=transforms.Compose([
                                                    transforms.ToTensor(),
                                                    transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                                         (0.2023, 0.1994, 0.2010)),
                                                ]))
    testset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=False, download=True,
                                               transform=transforms.Compose([
                                                   transforms.ToTensor(),
                                                   transforms.Normalize((0.4914, 0.4822, 0.4465),
                                                                        (0.2023, 0.1994, 0.2010)),
                                               ]))

    device = 'cuda:1'

    trainloader = DataLoader(trainset_c10, batch_size=batch_size, shuffle=True)
    testloader = DataLoader(testset_c10, batch_size=batch_size, shuffle=False)

    model = torchvision.models.vgg16()
    model.classifier[6] = nn.Linear(in_features=4096, out_features=10, bias=True)
    model = model.to(device)

    loss_function = nn.CrossEntropyLoss()
    optimiser = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimiser, milestones=[100, 150])

    # Initialize TensorBoard writer
    writer = SummaryWriter(log_dir=log_dir)

    for epoch in range(200):
        model.train()
        running_loss = 0.0
        for data in trainloader:
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)

            optimiser.zero_grad()

            outputs = model(inputs)
            loss = loss_function(outputs, labels)
            loss.backward()
            optimiser.step()

            running_loss += loss.item()

        scheduler.step()
        
        # Log the average loss at the end of each epoch
        avg_loss = running_loss / len(trainloader)
        writer.add_scalar('training_loss', avg_loss, epoch)
        print(f"Epoch {epoch + 1}, loss: {running_loss / len(trainloader):.4f}")

        # Log training accuracy
        model.eval()
        correct = 0
        total = 0
        for inputs, labels in DataLoader(trainset_c10, batch_size=128):
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            correct += (predicted == labels).sum().item()
            total += labels.size(0)
        train_accuracy = 100.0 * correct / total
        writer.add_scalar('training_accuracy', train_accuracy, epoch)

        print(f"Epoch {epoch + 1}, Loss: {avg_loss:.2f}, Training Accuracy: {train_accuracy:.2f}%")

    print('** Finished Training **')

    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for data in testloader:
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)

            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            correct += (predicted == labels).sum().item()
            total += labels.size(0)
        test_accuracy = 100.0 * correct / total
    writer.add_scalar('test_accuracy', test_accuracy)
    
    print(f"Test Accuracy: {test_accuracy:.2f}%")

    save_path = f"/ssd/yl38u22/VGG16_label_smoothing_0.01_seed{seed}.pt"
    torch.save(model.state_dict(), save_path)
    print(f'Model saved to {save_path}')

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train a model with specified learning rate and seed.')
    parser.add_argument('lr', type=float, help='Learning rate for training.')
    args = parser.parse_args()

    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)  # Pass 'lr' as the second argument
