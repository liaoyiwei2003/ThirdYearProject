import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import nn, optim
from torchbearer import Trial
import torchbearer
from torchvision.datasets import VisionDataset
import matplotlib.pyplot as plt
import torch.nn.functional as F
import random
import numpy as np
import sys
import os

from copy import deepcopy
from torch import nn

SEED=9
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.backends.cudnn.benchmark = False

import torch
from torch import nn

random.seed(SEED)
batch_size = 32
trainset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=True, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),]))
testset_c10 = torchvision.datasets.CIFAR10(root='~/data/cifar10', train=False, download=True,
                                           transform=transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465),
                             (0.2023, 0.1994, 0.2010)),]))

device = 'cuda:3'

import torchvision.transforms as transforms
from torch.utils.data import DataLoader

trainloader = DataLoader(trainset_c10, batch_size=128, shuffle=True)
testloader = DataLoader(testset_c10, batch_size=128, shuffle=True)

model = torchvision.models.vgg16()
model.classifier[6] = nn.Linear(in_features=4096, out_features=10, bias = True)
model = model.to(device)
loss_function = nn.CrossEntropyLoss()
optimiser = optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)
scheduler = optim.lr_scheduler.MultiStepLR(optimiser, milestones=[100,150])

for epoch in range(200):
    running_loss = 0.0
    for data in trainloader:

        # get the inputs
        inputs, labels = data
        inputs = inputs.to(device)
        labels = labels.to(device)

        # zero the parameter gradients
        optimiser.zero_grad()

        # forward + loss + backward + optimise (update weights)
        outputs = model(inputs)
        loss = loss_function(outputs, labels)
        loss.backward()
        optimiser.step()
        scheduler.step()

        # keep track of the loss this epoch
        running_loss += loss.item()
    print("Epoch %d, loss %4.2f" % (epoch, running_loss))
print('** Finished Training **')

model.eval() # ALWAYS DO THIS BEFORE YOU EVALUATE MODELS

# Compute the model accuracy on the test set
correct = 0
total = 0

for data in testloader:
    inputs, labels = data
    inputs = inputs.to(device)
    labels = labels.to(device)

    outputs = model(inputs)
    _, predicted = torch.max(outputs, 1)
    correct += (predicted==labels).sum().item()
    total += labels.size(0)

print(total)

print('Test Accuracy: %2.2f %%' % ((100.0 * correct) / total))

torch.save(model.state_dict(), "/ssd/saved_tutorial_models/yl38u22/VGG16_unmixup_200_seed9.pt")
