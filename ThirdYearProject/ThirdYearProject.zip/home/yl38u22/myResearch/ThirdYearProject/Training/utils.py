import torch
import torch.nn as nn
import torchvision
from torchvision import transforms
from torch import nn, optim
from torchbearer import Trial
import torchbearer
from torchvision.datasets import VisionDataset
import matplotlib.pyplot as plt
import torch.nn.functional as F
import random
import numpy as np

import random
from collections import defaultdict
def class_dict(dataset):
    class_idx = defaultdict(list)
    for i in range(0, len(dataset)):
        cls = dataset.__getitem__(i)[1]
        class_idx[cls].append(i)
    return class_idx

import random
from torch.distributions.beta import Beta
from torchvision.datasets import VisionDataset
from tqdm import tqdm
import torch.nn.functional as F

class MixedDatasetsDephased(VisionDataset):
    def __init__(self, dataset1, dataset2, n_cls, dephase=0, flip=False, im_size=32):
        self.root = None
        # dephase = 0: perfect corr
        # dephase = 1: dephase, label of first ds
        # dephase = -1: dephase, label of second ds
        self.dataset1 = dataset1
        self.dataset2 = dataset2
        self.im_size = im_size
        self.class_map2 = {}
        self.dephase = dephase
        self.flip = flip

        for i in range(0, len(dataset2)):
            image, target = dataset2.__getitem__(i)
            if int(target+dephase)%n_cls in self.class_map2:
                self.class_map2[(target+dephase)%n_cls].append(i)
            else:
                self.class_map2[(target+dephase)%n_cls] = [i]

    def __len__(self):
        return len(self.dataset1)

    def __getitem__(self, index):
        """
        Args:
            index (int): Index
        Returns:
            tuple: (image, target) where target is index of the target class.
        """
        img1, target1 = self.dataset1[index]
        index2 = random.choice(self.class_map2[target1])
        img2, target2 = self.dataset2[index2]
        
        if img1.shape[1] != self.im_size:
            img1 = F.pad(img1, pad = (2,2,2,2)).repeat(3,1,1)
        
        if img2.shape[1] != self.im_size:
            img2 = F.pad(img2, pad = (2,2,2,2)).repeat(3,1,1)

        #TODO: Make this nicer
        if self.dephase >= 0:
            t = target1
        else:
            t =  target2
        
        if self.flip:
            if random.randint(0,1) == 1:
                return torch.cat((img2, img1),2), t
        return torch.cat((img1, img2),2), t
    
def get_indices(idx, classes, corr=True, percentage=0.9):
    k = int(len(idx[0]) * percentage)
    all_indices = []
    if corr:
        for c in classes:
            all_indices += idx[c][:k]
    else:
        for c in classes:
            all_indices += idx[c][k:]
    return all_indices