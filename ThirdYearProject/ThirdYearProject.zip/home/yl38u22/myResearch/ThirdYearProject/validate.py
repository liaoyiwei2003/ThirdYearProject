import os
import shutil

def reorganize_validation_data(val_dir, new_val_dir, val_annotations_file):
    """
    Reorganize Tiny ImageNet validation data into class-specific folders.

    Args:
        val_dir (str): Path to the original validation images directory.
        new_val_dir (str): Path to the new directory for reorganized validation images.
        val_annotations_file (str): Path to the validation annotations file.
    """
    if not os.path.exists(new_val_dir):
        os.makedirs(new_val_dir, exist_ok=True)
        with open(val_annotations_file, 'r') as f:
            for line in f:
                parts = line.strip().split('\t')
                img_name = parts[0]
                class_id = parts[1]
                src_path = os.path.join(val_dir, img_name)
                dst_dir = os.path.join(new_val_dir, class_id)
                os.makedirs(dst_dir, exist_ok=True)
                dst_path = os.path.join(dst_dir, img_name)
                shutil.move(src_path, dst_path)
        print(f"Validation data reorganized and saved to {new_val_dir}")
    else:
        print(f"Validation data already reorganized at {new_val_dir}")

if __name__ == "__main__":
    # Define paths
    val_dir = "/data/tiny-imagenet-200/val/images"
    new_val_dir = "/data/tiny-imagenet-200/val_images"
    val_annotations_file = "/data/tiny-imagenet-200/val/val_annotations.txt"

    # Reorganize validation data
    reorganize_validation_data(val_dir, new_val_dir, val_annotations_file)