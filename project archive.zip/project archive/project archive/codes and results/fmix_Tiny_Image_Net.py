import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np
import math
from scipy.stats import beta

# FMix Functions (already provided in the query)
def fftfreqnd(h, w=None, z=None):
    fz = fx = 0
    fy = np.fft.fftfreq(h)
    if w is not None:
        fy = np.expand_dims(fy, -1)
        if w % 2 == 1:
            fx = np.fft.fftfreq(w)[: w // 2 + 2]
        else:
            fx = np.fft.fftfreq(w)[: w // 2 + 1]
    if z is not None:
        fy = np.expand_dims(fy, -1)
        if z % 2 == 1:
            fz = np.fft.fftfreq(z)[:, None]
        else:
            fz = np.fft.fftfreq(z)[:, None]
    return np.sqrt(fx * fx + fy * fy + fz * fz)

def get_spectrum(freqs, decay_power, ch, h, w=0, z=0):
    scale = np.ones(1) / (np.maximum(freqs, np.array([1. / max(w, h, z)])) ** decay_power)
    param_size = [ch] + list(freqs.shape) + [2]
    param = np.random.randn(*param_size)
    scale = np.expand_dims(scale, -1)[None, :]
    return scale * param

def make_low_freq_image(decay, shape, ch=1):
    freqs = fftfreqnd(*shape)
    spectrum = get_spectrum(freqs, decay, ch, *shape)
    spectrum = spectrum[:, 0] + 1j * spectrum[:, 1]
    mask = np.real(np.fft.irfftn(spectrum, shape))
    if len(shape) == 1:
        mask = mask[:1, :shape[0]]
    if len(shape) == 2:
        mask = mask[:1, :shape[0], :shape[1]]
    if len(shape) == 3:
        mask = mask[:1, :shape[0], :shape[1], :shape[2]]
    mask = (mask - mask.min()) / mask.max()
    return mask

def sample_lam(alpha, reformulate=False):
    if reformulate:
        lam = beta.rvs(alpha+1, alpha)
    else:
        lam = beta.rvs(alpha, alpha)
    return lam

def binarise_mask(mask, lam, in_shape, max_soft=0.0):
    idx = mask.reshape(-1).argsort()[::-1]
    mask = mask.reshape(-1)
    num = math.ceil(lam * mask.size) if random.random() > 0.5 else math.floor(lam * mask.size)
    eff_soft = min(max_soft, lam, 1-lam)
    soft = int(mask.size * eff_soft)
    num_low = num - soft
    num_high = num + soft
    mask[idx[:num_high]] = 1
    mask[idx[num_low:]] = 0
    mask[idx[num_low:num_high]] = np.linspace(1, 0, (num_high - num_low))
    mask = mask.reshape((1, *in_shape))
    return mask

def sample_mask(alpha, decay_power, shape, max_soft=0.0, reformulate=False):
    if isinstance(shape, int):
        shape = (shape,)
    lam = sample_lam(alpha, reformulate)
    mask = make_low_freq_image(decay_power, shape)
    mask = binarise_mask(mask, lam, shape, max_soft)
    return lam, mask

# Helper function
def create_log_dir(path):
    os.makedirs(path, exist_ok=True)

# Main training function
def train_model_with_seed(seed, lr):
    # Set random seeds
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Initialize logging
    log_dir = f'~/logs/tinyimagenet_fmix_seed_{seed}_lr_{lr}'
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)

    # Data preprocessing
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Dataset loading
    train_dir = "/Users/yl38u22/myResearch/data/tiny-imagenet-200/train"
    val_dir = "/Users/yl38u22/myResearch/data/tiny-imagenet-200/val_images"
    train_dataset = datasets.ImageFolder(train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(val_dir, transform=val_transform)

    # Data loaders
    batch_size = 128
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    # Model definition
    model = torchvision.models.resnet18()
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()
    model.fc = nn.Linear(512, 200)
    device = 'cuda:1'
    model = model.to(device)

    # Optimizer configuration
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimizer, milestones=[100, 150], gamma=0.1)
    criterion = nn.CrossEntropyLoss()

    # Training loop
    for epoch in range(100):
        model.train()
        running_loss = 0.0
        train_correct = 0
        train_total = 0
        
        # Training phase
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            # FMix parameters
            alpha = 1.0
            decay_power = 1
            shape = (64, 64)
            max_soft = 0.0
            reformulate = False
            
            # Generate FMix mask
            lam, mask = sample_mask(alpha, decay_power, shape, max_soft, reformulate)
            mask = torch.from_numpy(mask).float().to(device)
            
            # Generate permutation indices
            index = torch.randperm(inputs.size(0), device=device)
            
            # Apply FMix
            mixed_inputs = inputs * mask + inputs[index] * (1 - mask)
            
            # Forward pass
            outputs = model(mixed_inputs)
            
            # Compute loss
            loss = lam * criterion(outputs, labels) + (1 - lam) * criterion(outputs, labels[index])
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            # Statistics
            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            train_total += labels.size(0)
            train_correct += (predicted == labels).sum().item()

        # Learning rate adjustment
        scheduler.step()
        
        # Compute training metrics
        avg_loss = running_loss / len(train_loader)
        train_acc = 100 * train_correct / train_total
        writer.add_scalar('Loss/train', avg_loss, epoch)
        writer.add_scalar('Accuracy/train', train_acc, epoch)

        # Validation phase
        model.eval()
        val_correct = 0
        val_total = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                val_total += labels.size(0)
                val_correct += (predicted == labels).sum().item()
        
        # Compute validation metrics
        val_acc = 100 * val_correct / val_total
        writer.add_scalar('Accuracy/val', val_acc, epoch)

        # Print logs
        print(f"Epoch {epoch+1}/100 => "
              f"Loss: {avg_loss:.4f} | "
              f"Train Acc: {train_acc:.2f}% | "
              f"Val Acc: {val_acc:.2f}%")

    # Save model
    save_path = f"/ssd/yl38u22/tinyimagenet_fmix_seed{seed}_lr{lr}.pt"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Learning rate')
    args = parser.parse_args()
    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)