import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np
from scipy.stats import beta

def create_log_dir(path):
    """Create a directory for logging if it doesn't exist."""
    os.makedirs(path, exist_ok=True)

def train_model_with_seed(seed, lr):
    """
    Train a ResNet-18 model on Tiny ImageNet with a given seed and learning rate.

    Args:
        seed (int): Random seed for reproducibility.
        lr (float): Learning rate for training.
    """
    # Set seeds for reproducibility
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Define log directory
    log_dir = f'~/logs/tinyimagenet_mixup_seed_{seed}_lr_{lr}'
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)

    # Data transforms with augmentation for training
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    # Load Tiny ImageNet datasets
    train_dir = "/Users/yl38u22/myResearch/data/tiny-imagenet-200/train"
    val_dir = "/Users/yl38u22/myResearch/data/tiny-imagenet-200/val_images"
    train_dataset = datasets.ImageFolder(train_dir, transform=train_transform)
    val_dataset = datasets.ImageFolder(val_dir, transform=val_transform)

    # Create data loaders
    batch_size = 128
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    # Define modified ResNet-18 for 64x64 inputs
    model = torchvision.models.resnet18()
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()  # Remove initial maxpool
    model.fc = nn.Linear(512, 200)  # 200 classes for Tiny ImageNet
    device = 'cuda:1'
    model = model.to(device)

    # Training hyperparameters
    ALPHA = 0.2
    loss_function = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimizer, milestones=[100, 150], gamma=0.1)

    # Training loop
    for epoch in range(100):
        model.train()
        running_loss = 0.0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            indices = torch.randperm(inputs.size(0), device=device)
            lam = np.random.beta(ALPHA, ALPHA)

            # Mixup inputs and labels
            if lam > 0.5:
                mixed_inputs = inputs
            else:
                mixed_inputs = inputs[indices]
            
            optimizer.zero_grad()
            outputs = model(mixed_inputs)
            loss = lam * loss_function(outputs, labels) + (1 - lam) * loss_function(outputs, labels[indices])
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / len(train_loader)
        writer.add_scalar('training_loss', avg_loss, epoch)

        # Training accuracy
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, labels in train_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
                total += labels.size(0)
        train_acc = 100 * correct / total
        writer.add_scalar('train_accuracy', train_acc, epoch)

        # Validation accuracy
        correct_val = 0
        total_val = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                correct_val += (predicted == labels).sum().item()
                total_val += labels.size(0)
        val_acc = 100 * correct_val / total_val
        writer.add_scalar('val_accuracy', val_acc, epoch)

        print(f"Epoch {epoch}: Loss={avg_loss:.4f}, Train Acc={train_acc:.2f}%, Val Acc={val_acc:.2f}%")

    # Save model
    save_path = f"/ssd/yl38u22/tinyimagenet_mixup_seed{seed}_lr{lr}.pt"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Learning rate')
    args = parser.parse_args()
    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)