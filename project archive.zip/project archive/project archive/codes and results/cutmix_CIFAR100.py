import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np

# Custom CutMix class for CIFAR-100
class FixedPositionCutMix:
    def __init__(self, src_crop_box=(8, 8, 16), dst_paste_box=(8, 8, 16)):
        """
        Fixed position CutMix for CIFAR-100
        CIFAR-100 images are 32x32, default crop is 16x16
        """
        self.src_box = src_crop_box
        self.dst_box = dst_paste_box
        self.lam = 1 - (src_crop_box[2]**2) / (32**2)  # Calculate lambda value

    def __call__(self, img_a, img_b):
        src_x, src_y, crop_size = self.src_box
        dst_x, dst_y, _ = self.dst_box
        
        # Crop from img_a and paste onto img_b
        patch = img_a[:, src_y:src_y+crop_size, src_x:src_x+crop_size]
        mixed_img = img_b.clone()
        mixed_img[:, dst_y:dst_y+crop_size, dst_x:dst_x+crop_size] = patch
        return mixed_img, self.lam

def create_log_dir(path):
    os.makedirs(path, exist_ok=True)

def train_model_with_seed(seed, lr):
    # Set random seeds for reproducibility
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Log directory for CIFAR-100
    log_dir = os.path.expanduser(f'~/logs/cifar100_cutmix_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)

    # Data augmentation (same as CIFAR-10, assuming similar normalization)
    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])

    # Load CIFAR-100 dataset
    train_dataset = datasets.CIFAR100(
        root=os.path.expanduser('~/data/cifar100'),
        train=True,
        download=True,
        transform=train_transform
    )
    test_dataset = datasets.CIFAR100(
        root=os.path.expanduser('~/data/cifar100'),
        train=False,
        download=True,
        transform=test_transform
    )

    # Data loaders
    batch_size = 128
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True)

    # Model definition (adjusted for 100 classes)
    model = torchvision.models.resnet18()
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()
    model.fc = nn.Linear(512, 100)  # Updated to 100 classes for CIFAR-100
    device = 'cuda:1' if torch.cuda.is_available() else 'cpu'
    model = model.to(device)

    # Initialize CutMix (parameters suitable for CIFAR-100's 32x32 images)
    cutmix = FixedPositionCutMix(
        src_crop_box=(0, 0, 16),  # Crop 16x16 region from 32x32 image
        dst_paste_box=(0, 0, 16)  # Paste to top-left corner
    )

    # Optimizer and scheduler configuration
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimizer, milestones=[50, 100], gamma=0.05)

    # Training loop
    for epoch in range(150):
        model.train()
        running_loss = 0.0
        train_correct = 0
        train_total = 0
        
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            # Generate random indices for CutMix
            indices = torch.randperm(inputs.size(0), device=device)
            
            # Apply CutMix
            mixed_inputs, lam = cutmix(inputs, inputs[indices])
            
            optimizer.zero_grad()
            outputs = model(mixed_inputs)
            
            # Compute combined loss
            loss = lam * criterion(outputs, labels) + (1 - lam) * criterion(outputs, labels[indices])
            
            loss.backward()
            optimizer.step()
            
            # Track metrics
            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            train_total += labels.size(0)
            train_correct += (predicted == labels).sum().item()

        scheduler.step()
        
        # Compute training metrics
        avg_loss = running_loss / len(train_loader)
        train_acc = 100 * train_correct / train_total
        writer.add_scalar('Loss/train', avg_loss, epoch)
        writer.add_scalar('Accuracy/train', train_acc, epoch)

        # Test set evaluation
        model.eval()
        test_correct = 0
        test_total = 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                test_total += labels.size(0)
                test_correct += (predicted == labels).sum().item()
        
        test_acc = 100 * test_correct / test_total
        writer.add_scalar('Accuracy/test', test_acc, epoch)

        print(f"Epoch {epoch+1}: Loss={avg_loss:.4f}, Train Acc={train_acc:.2f}%, Test Acc={test_acc:.2f}%")

    # Save model with CIFAR-100 specific path
    save_path = f"/ssd/yl38u22/cifar100_cutmix_seed{seed}_lr{lr}.pt"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Learning rate')
    args = parser.parse_args()
    for seed in [5，6，7，8，9]:
        train_model_with_seed(seed, args.lr)