import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np

def create_log_dir(path):
    """Create a directory for logging if it doesn't exist."""
    os.makedirs(path, exist_ok=True)

def train_model_with_seed(seed, lr):
    """
    Train a ResNet-18 model on CIFAR-10 with a given seed and learning rate.
    """
    # Set seeds for reproducibility
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # Define log directory
    log_dir = os.path.expanduser(f'~/logs/cifar10_mixup_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)

    # Data transforms with augmentation
    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])

    # Load CIFAR-10 datasets
    train_dataset = datasets.CIFAR10(
        root=os.path.expanduser('~/data/cifar10'),
        train=True,
        download=True,
        transform=train_transform
    )
    test_dataset = datasets.CIFAR10(
        root=os.path.expanduser('~/data/cifar10'),
        train=False,
        download=True,
        transform=test_transform
    )

    # Create data loaders
    batch_size = 128
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True)

    # Define modified ResNet-18 for CIFAR-10
    model = torchvision.models.resnet18()
    # Adjust for 32x32 input
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()  # Remove initial maxpool
    model.fc = nn.Linear(512, 10)  # 10 classes for CIFAR-10
    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    model = model.to(device)

    # Training hyperparameters
    ALPHA = 0.2
    loss_function = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimizer, milestones=[50, 100], gamma=0.05)  # Adjusted for CIFAR-10

    # Training loop
    for epoch in range(150):  # Extended to 150 epochs
        model.train()
        running_loss = 0.0
        
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            # Generate mixed inputs
            indices = torch.randperm(inputs.size(0), device=device)
            lam = np.random.beta(ALPHA, ALPHA)
            
            # Correct mixup implementation
            mixed_inputs = lam * inputs + (1 - lam) * inputs[indices]
            
            optimizer.zero_grad()
            outputs = model(mixed_inputs)
            loss = lam * loss_function(outputs, labels) + (1 - lam) * loss_function(outputs, labels[indices])
            
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / len(train_loader)
        writer.add_scalar('training_loss', avg_loss, epoch)

        # Training accuracy
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, labels in train_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                correct += (predicted == labels).sum().item()
                total += labels.size(0)
        train_acc = 100 * correct / total
        writer.add_scalar('train_accuracy', train_acc, epoch)

        # Test accuracy
        correct_test = 0
        total_test = 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                correct_test += (predicted == labels).sum().item()
                total_test += labels.size(0)
        test_acc = 100 * correct_test / total_test
        writer.add_scalar('test_accuracy', test_acc, epoch)

        print(f"Epoch {epoch}: Loss={avg_loss:.4f}, Train Acc={train_acc:.2f}%, Test Acc={test_acc:.2f}%")

    # Save model
    save_path = f"/ssd/yl38u22/cifar10_mixup_seed{seed}_lr{lr}.pt'"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Learning rate')
    args = parser.parse_args()
    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)