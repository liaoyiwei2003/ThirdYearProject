import os
import shutil
from pathlib import Path

def extract_images(source_dir, target_dir, num_samples=5):
    """
    从每个训练类别中提取指定数量的图片
    参数：
        source_dir: Tiny ImageNet 训练集目录（格式为 tiny-imagenet-200/train）
        target_dir: 目标保存目录
        num_samples: 每个类别提取的图片数量（默认 5）
    """
    # 创建目标目录
    Path(target_dir).mkdir(parents=True, exist_ok=True)
    
    # 遍历每个类别目录
    for class_dir in os.listdir(source_dir):
        class_path = os.path.join(source_dir, class_dir, 'images')
        
        # 获取所有图片文件
        all_images = [f for f in os.listdir(class_path) if f.endswith('.JPEG')]
        
        # 选择前 num_samples 张图片
        selected_images = all_images[:num_samples]
        
        # 复制到目标目录（添加类别前缀避免文件名冲突）
        for img in selected_images:
            src = os.path.join(class_path, img)
            dst = os.path.join(target_dir, f"{class_dir}_{img}")
            shutil.copy(src, dst)

if __name__ == "__main__":
    # 原始数据路径（根据实际情况修改）
    train_dir = "C:/Users/23885/Desktop/thirdyearproject/code/tinyimagenet/tiny-imagenet-200/train"
    
    # 目标保存路径
    output_dir = "sampled_images"
    
    # 执行提取
    extract_images(train_dir, output_dir)
    print(f"成功从每个类别提取 5 张图片到 {output_dir} 目录")