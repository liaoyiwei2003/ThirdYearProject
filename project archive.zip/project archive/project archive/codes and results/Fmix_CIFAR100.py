import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np
import math
from scipy.stats import beta

def fftfreqnd(h, w=None, z=None):
    """ Get bin values for discrete fourier transform of size (h, w, z) """
    fz = fx = 0
    fy = np.fft.fftfreq(h)

    if w is not None:
        fy = np.expand_dims(fy, -1)
        if w % 2 == 1:
            fx = np.fft.fftfreq(w)[: w // 2 + 2]
        else:
            fx = np.fft.fftfreq(w)[: w // 2 + 1]

    if z is not None:
        fy = np.expand_dims(fy, -1)
        if z % 2 == 1:
            fz = np.fft.fftfreq(z)[:, None]
        else:
            fz = np.fft.fftfreq(z)[:, None]

    return np.sqrt(fx * fx + fy * fy + fz * fz)

def get_spectrum(freqs, decay_power, ch, h, w=0, z=0):
    """ Samples a fourier image with given size and frequencies decayed by decay power """
    scale = np.ones(1) / (np.maximum(freqs, np.array([1. / max(w, h, z)])) ** decay_power)
    param_size = [ch] + list(freqs.shape) + [2]
    param = np.random.randn(*param_size)
    scale = np.expand_dims(scale, -1)[None, :]
    return scale * param

def make_low_freq_image(decay, shape, ch=1):
    """ Sample a low frequency image from fourier space """
    freqs = fftfreqnd(*shape)
    spectrum = get_spectrum(freqs, decay, ch, *shape)
    spectrum = spectrum[:, 0] + 1j * spectrum[:, 1]
    mask = np.real(np.fft.irfftn(spectrum, shape))
    
    if len(shape) == 1:
        mask = mask[:1, :shape[0]]
    if len(shape) == 2:
        mask = mask[:1, :shape[0], :shape[1]]
    if len(shape) == 3:
        mask = mask[:1, :shape[0], :shape[1], :shape[2]]
    
    mask = (mask - mask.min())
    mask = mask / mask.max()
    return mask

def sample_lam(alpha, reformulate=False):
    """ Sample a lambda from symmetric beta distribution """
    if reformulate:
        return beta.rvs(alpha+1, alpha)
    return beta.rvs(alpha, alpha)

def binarise_mask(mask, lam, in_shape, max_soft=0.0):
    """ Binarises a given low frequency image """
    idx = mask.reshape(-1).argsort()[::-1]
    mask = mask.reshape(-1)
    num = math.ceil(lam * mask.size) if random.random() > 0.5 else math.floor(lam * mask.size)

    eff_soft = max_soft
    if max_soft > lam or max_soft > (1-lam):
        eff_soft = min(lam, 1-lam)

    soft = int(mask.size * eff_soft)
    num_low = num - soft
    num_high = num + soft

    mask[idx[:num_high]] = 1
    mask[idx[num_low:]] = 0
    mask[idx[num_low:num_high]] = np.linspace(1, 0, (num_high - num_low))
    return mask.reshape((1, *in_shape))

def sample_mask(alpha, decay_power, shape, max_soft=0.0, reformulate=False):
    """ Samples FMix mask """
    if isinstance(shape, int):
        shape = (shape,)
    lam = sample_lam(alpha, reformulate)
    mask = make_low_freq_image(decay_power, shape)
    mask = binarise_mask(mask, lam, shape, max_soft)
    return lam, mask

def apply_fmix(inputs, alpha=1.0, decay_power=3.0, max_soft=0.0, reformulate=False):
    """ 应用FMix的辅助函数 """
  
    lam, mask = sample_mask(
        alpha=alpha,
        decay_power=decay_power,
        shape=(32, 32),  
        max_soft=max_soft,
        reformulate=reformulate
    )
    mask = torch.tensor(mask, device=inputs.device).float()
    
 
    indices = torch.randperm(inputs.size(0), device=inputs.device)
    
  
    mixed_inputs = inputs * mask + inputs[indices] * (1 - mask)
    return mixed_inputs, indices, lam


def create_log_dir(path):
    os.makedirs(path, exist_ok=True)

def train_model_with_seed(seed, lr):

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

 
    log_dir = os.path.expanduser(f'~/logs/cifar100_fmix_orig_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)


    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])

   
    train_dataset = datasets.CIFAR100(
        root=os.path.expanduser('~/data/cifar100'),
        train=True,
        download=True,
        transform=train_transform
    )
    test_dataset = datasets.CIFAR100(
        root=os.path.expanduser('~/data/cifar100'),
        train=False,
        download=True,
        transform=test_transform
    )


    batch_size = 128
    train_loader = DataLoader(train_dataset, batch_size=batch_size, 
                            shuffle=True, num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size,
                           shuffle=False, num_workers=4, pin_memory=True)


    model = torchvision.models.resnet18()
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()
    model.fc = nn.Linear(512, 100)  
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4)
    scheduler = MultiStepLR(optimizer, milestones=[100, 150], gamma=0.05)


    for epoch in range(150):
        model.train()
        total_loss = 0.0
        correct = 0
        total = 0
        
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device, non_blocking=True), labels.to(device)
            
            mixed_inputs, indices, lam = apply_fmix(
                inputs,
                alpha=1.0,
                decay_power=3.0,
                max_soft=0.0,
                reformulate=False
            )
            
        
            outputs = model(mixed_inputs)
            
           
            loss = lam * criterion(outputs, labels) + (1 - lam) * criterion(outputs, labels[indices])
            
         
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            
        
            total_loss += loss.item() * inputs.size(0)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    
        scheduler.step()
        
        avg_loss = total_loss / total
        train_acc = 100.0 * correct / total
        writer.add_scalar('Loss/train', avg_loss, epoch)
        writer.add_scalar('Accuracy/train', train_acc, epoch)

     
        model.eval()
        test_correct = 0
        test_total = 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                test_total += labels.size(0)
                test_correct += (predicted == labels).sum().item()
        
        test_acc = 100.0 * test_correct / test_total
        writer.add_scalar('Accuracy/test', test_acc, epoch)

        print(f"Epoch {epoch+1:03d}/150 | "
              f"Loss: {avg_loss:.4f} | "
              f"Train Acc: {train_acc:.2f}% | "
              f"Test Acc: {test_acc:.2f}%")


    save_path = f"/ssd/yl38u22/cifar100_fmix_orig_seed{seed}_lr{lr}.pt"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Initial learning rate')
    args = parser.parse_args()
    
    for seed in [5，6，7，8，9]:
        train_model_with_seed(seed, args.lr)