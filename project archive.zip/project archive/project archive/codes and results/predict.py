import cv2
import numpy as np
from detectron2.engine import DefaultPredictor
from detectron2.config import get_cfg
from detectron2 import model_zoo

cfg = get_cfg()
cfg.merge_from_file(model_zoo.get_config_file("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"))
cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.5  
cfg.MODEL.WEIGHTS = model_zoo.get_checkpoint_url("COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml")
predictor = DefaultPredictor(cfg)


image_path = "path/to/tiny_imagenet_image.jpg"  
image = cv2.imread(image_path)
image = cv2.resize(image, (224, 224)) 


outputs = predictor(image)
instances = outputs["instances"]
pred_classes = instances.pred_classes 
pred_boxes = instances.pred_boxes     
pred_masks = instances.pred_masks     
for i in range(len(pred_classes)):
    class_id = pred_classes[i].item()
    box = pred_boxes[i].tensor.cpu().numpy()
    mask = pred_masks[i].cpu().numpy()
    print(f"物体 {i+1}: 类别ID={class_id}, 边界框={box}")