import os
from PIL import Image
import json
from torchvision.datasets import CIFAR10

# CIFAR-10类别名称
classes = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# 创建保存图像的目录
output_dir = 'cifar10_images'
os.makedirs(output_dir, exist_ok=True)

# 加载CIFAR-10训练集
dataset = CIFAR10(root='./data', train=True, download=True)

# 定义生成Labelme JSON的函数
def create_labelme_json(image_path, label):
    annotation = {
        "version": "5.0.1",  # Labelme版本号
        "flags": {},
        "shapes": [
            {
                "label": label,  # 类别标签，如"airplane"
                "points": [[0, 0], [32, 32]],  # 边界框坐标，覆盖整个图像
                "group_id": None,
                "shape_type": "rectangle",
                "flags": {}
            }
        ],
        "imagePath": os.path.basename(image_path),  # 图像文件名
        "imageData": None,  # 不嵌入图像数据，依赖外部文件
        "imageHeight": 32,
        "imageWidth": 32
    }
    return annotation

# 处理数据集
for i, (image, label_idx) in enumerate(dataset):
    # 保存图像
    image_path = os.path.join(output_dir, f'image_{i:05d}.png')
    image.save(image_path)

    # 获取类别标签
    label = classes[label_idx]

    # 生成JSON标注
    annotation = create_labelme_json(image_path, label)
    json_path = os.path.join(output_dir, f'image_{i:05d}.json')
    with open(json_path, 'w') as f:
        json.dump(annotation, f, indent=2)

print(f"已生成{len(dataset)}个图像和对应的Labelme标注文件，保存在'{output_dir}'目录中。")