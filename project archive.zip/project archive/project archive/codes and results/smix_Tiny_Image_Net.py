import os
import argparse
import torch
import torch.nn as nn
import torchvision
from torchvision import transforms, datasets, models
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader, Dataset
from torch.optim.lr_scheduler import MultiStepLR
import random
import numpy as np
from PIL import Image
import cv2
from torch.cuda.amp import GradScaler, autocast
from tqdm import tqdm
import time
from torchvision.transforms.functional import hflip

def create_log_dir(path):
    """Create a directory for logging if it doesn't exist."""
    os.makedirs(path, exist_ok=True)

class TinyImageNetWithMasks(Dataset):
    def __init__(self, dataset, masks):
        self.dataset = dataset
        self.masks = masks  # Precomputed masks

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        image, label = self.dataset[idx]
        mask = self.masks[idx]
        return image, label, mask

class MaskProcessor:
    def __init__(self):
        self.color_map = self._create_color_map()
        
    def _create_color_map(self):
        cmap = np.zeros((256, 3), dtype=np.uint8)
        cmap[0] = [0, 0, 0]
        np.random.seed(42)
        cmap[1:] = np.random.randint(25, 256, (255, 3))
        return cmap
    
    def _postprocess_mask(self, mask, original_size=(64, 64)):
        binary_mask = np.where(mask > 0, 255, 0).astype(np.uint8)
        binary_mask = cv2.GaussianBlur(binary_mask, (3, 3), 0)
        thresh = cv2.adaptiveThreshold(
            binary_mask, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 5, 2
        )
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        opened = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
        contours, _ = cv2.findContours(opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        filled_mask = np.zeros_like(binary_mask)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            cv2.drawContours(filled_mask, [largest_contour], -1, 255, thickness=cv2.FILLED)
        return cv2.resize(filled_mask, original_size, interpolation=cv2.INTER_NEAREST)

class TinyImageNetSemanticMixer:
    def __init__(self, device):
        self.device = device
        self.seg_model = models.segmentation.deeplabv3_mobilenet_v3_large(
            weights=models.segmentation.DeepLabV3_MobileNet_V3_Large_Weights.DEFAULT
        ).to(device).eval()
        self.processor = MaskProcessor()
        self.transform = transforms.Compose([
            transforms.Resize(64),
            transforms.Lambda(lambda x: x.convert('RGB') if x.mode != 'RGB' else x),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    
    def precompute_masks(self, dataset, save_dir='~/data/tinyimagenet_masks', batch_size=128):
        #The progress bar tracks batches, not individual images. With a batch size of 128 and 100,000 images, the number of batches is: 100000/128=783
        #This number can be seen on the status bar
        save_dir = os.path.expanduser(save_dir)
        os.makedirs(save_dir, exist_ok=True)
        masks = []
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True)
        
        start_time = time.time()
        for batch_idx, (img_tensors, _) in enumerate(tqdm(loader, desc="Precomputing masks", total=len(loader))):
            img_tensors = img_tensors.to(self.device)
            with torch.no_grad():
                outputs = self.seg_model(img_tensors)['out']
                batch_masks = torch.argmax(outputs, dim=1).cpu().numpy()
            for i in range(len(batch_masks)):
                idx = batch_idx * batch_size + i
                if idx >= len(dataset):
                    break
                mask_path = os.path.join(save_dir, f'mask_{idx}.npy')
                if os.path.exists(mask_path):
                    try:
                        mask = np.load(mask_path)
                        # Verify mask integrity
                        if mask.shape == (64, 64) and mask.dtype == np.uint8:
                            masks.append(torch.from_numpy(mask).float() / 255.0)
                            continue
                    except Exception:
                        print(f"Corrupted mask file detected: {mask_path}. Regenerating...")
                # Generate new mask
                mask = self.processor._postprocess_mask(batch_masks[i])
                np.save(mask_path, mask)
                masks.append(torch.from_numpy(mask).float() / 255.0)
        
        end_time = time.time()
        print(f"Mask precomputing completed in {end_time - start_time:.2f} seconds.")
        return masks

    def generate_smix(self, inputs, masks, alpha=0.4):
        indices = torch.randperm(inputs.size(0), device=self.device)
        shuffled_inputs = inputs[indices]
        mask_tensor = masks.to(self.device) * alpha
        mask_tensor = mask_tensor[:, None, :, :]  # Add channel dimension
        mixed_inputs = inputs * mask_tensor + shuffled_inputs * (1 - mask_tensor)
        return mixed_inputs, indices

class TinyImageNetWithMasks(Dataset):
    def __init__(self, dataset, masks):
        self.dataset = dataset
        self.masks = masks  # Precomputed masks

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        image, label = self.dataset[idx]
        mask = self.masks[idx]
        if random.random() < 0.5:
            image = hflip(image)
            mask = hflip(mask)
        return image, label, mask

def train_model_with_seed(seed, lr):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    smix_generator = TinyImageNetSemanticMixer(device)
    log_dir = os.path.expanduser(f'~/logs/tinyimagenet_smix_seed_{seed}_lr_{lr}')
    create_log_dir(log_dir)
    writer = SummaryWriter(log_dir=log_dir)

    train_transform = transforms.Compose([
        transforms.RandomCrop(64, padding=8),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    val_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    train_dataset = datasets.ImageFolder(
        root='/Users/yl38u22/myResearch/data/tiny-imagenet-200/train',
        transform=train_transform
    )
    val_dataset = datasets.ImageFolder(
        root='/Users/yl38u22/myResearch/data/tiny-imagenet-200/val_images',
        transform=val_transform
    )

    print("Precomputing masks...")
    masks = smix_generator.precompute_masks(train_dataset)
    train_dataset_with_masks = TinyImageNetWithMasks(train_dataset, masks)

    batch_size = 128
    train_loader = DataLoader(
        train_dataset_with_masks, batch_size=batch_size, shuffle=True, 
        num_workers=8, pin_memory=True, prefetch_factor=2
    )
    val_loader = DataLoader(
        val_dataset, batch_size=batch_size, shuffle=False, 
        num_workers=8, pin_memory=True
    )

    model = torchvision.models.resnet18()
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()
    model.fc = nn.Linear(512, 200)
    model = model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)
    scheduler = MultiStepLR(optimizer, milestones=[100, 150], gamma=0.1)
    scaler = GradScaler()

    for epoch in range(100):
        model.train()
        running_loss = 0.0
        
        for inputs, labels, masks in train_loader:
            inputs, labels, masks = inputs.to(device), labels.to(device), masks.to(device)
            
            mixed_inputs, indices = smix_generator.generate_smix(inputs, masks)
            labels2 = labels[indices]
            
            with autocast():
                outputs = model(mixed_inputs)
                loss = 0.5 * (criterion(outputs, labels) + criterion(outputs, labels2))
            
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            
            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / len(train_loader)
        writer.add_scalar('training_loss', avg_loss, epoch)

        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for inputs, labels, _ in train_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
                total += labels.size(0)
        train_acc = 100 * correct / total
        writer.add_scalar('train_accuracy', train_acc, epoch)

        correct_val = 0
        total_val = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                correct_val += (predicted == labels).sum().item()
                total_val += labels.size(0)
        val_acc = 100 * correct_val / total_val
        writer.add_scalar('val_accuracy', val_acc, epoch)

        print(f"Epoch {epoch}: Loss={avg_loss:.4f}, Train Acc={train_acc:.2f}%, Val Acc={val_acc:.2f}%")

    save_path = f"/ssd/yl38u22/tinyimagenet_smix_seed{seed}_lr{lr}.pt"
    torch.save(model.state_dict(), save_path)
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('lr', type=float, help='Learning rate')
    args = parser.parse_args()
    for seed in [5, 6, 7, 8, 9]:
        train_model_with_seed(seed, args.lr)